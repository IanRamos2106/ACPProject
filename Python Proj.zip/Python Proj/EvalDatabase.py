import mysql.connector

def collect_data(query):
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="eval",
    )


    cursor = conn.cursor()

    # Execute the query passed as a parameter
    cursor.execute(query)

    # Fetch all results from the executed query
    results = cursor.fetchall()

    # Close the connection
    conn.close()

    # Return the fetched data
    return results

def Dropdown_for_db():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="eval",
        )
    
    cursor = conn.cursor()
    # Adjust the table and column name as per your database structure
    cursor.execute("SELECT ECName FROM Ec")  
    items = [row[0] for row in cursor.fetchall()]  # Fetch all item_name values
    return items

def Dropdown_for_dbEl():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="eval",
        )
    
    cursor = conn.cursor()
    # Adjust the table and column name as per your database structure
    cursor.execute("SELECT Name,Wattage FROM El Where Name Not LIKE '%aircon%' and Name Not Like '%Fridge%';")  
    result = cursor.fetchall()

    # Close the connection
    cursor.close()
    conn.close()

    # Return the data (list of tuples)
    return result
