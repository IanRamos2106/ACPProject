import tkinter as tk
import os
import EvalDatabase
import mysql.connector

from tkinter import *
from tkinter import ttk
from EvalDatabase import collect_data
from EvalDatabase import Dropdown_for_db
from EvalDatabase import Dropdown_for_dbEl


#Setting the image directory Remind the user to properly select file directory
os.chdir("C:/Users/Ramos/Desktop/Python Proj/assets/images")

#Initialize the item windows

#=============================================================== 3 OUTLET EXTENSION =============================================================
def Outlet3Extension():
    
    #Create new window
    Outlet3 = tk.Tk()
    Outlet3.geometry("702x960")
    Outlet3.title("Extension Simulator")
    Outlet3.config(bg="black")
    Outlet3.resizable(0,0)

    global ExtShell
    ExtShell = PhotoImage(file='Extensions/03/03-Shell.png')
    ExtLabel = Label(Outlet3, image=ExtShell)
    ExtLabel.pack()

     # Fetch items from MySQL database
    items = Dropdown_for_dbEl()
    if not items:
        items = ["No items found"]  # Fallback if no data is fetched

    # Extract names for the dropdown
    item_names = [item[0] for item in items]

    # Create a label
    label = tk.Label(Outlet3, text="Select an Item:", font=("Arial", 14))
    label.place(x=190,y=250)
    
    # Create a dropdown (combobox1)
    selected_item = tk.StringVar()
    dropdown = ttk.Combobox(Outlet3, textvariable=selected_item, state="readonly", values=item_names, font=("Arial", 12))
    dropdown.place(x=190,y=280)
    dropdown.set("Select an option")  # Default text

    # Create a label
    label2 = tk.Label(Outlet3, text="Select an Item:", font=("Arial", 14))
    label2.place(x=170,y=390)

    # Extract names for the dropdown
    item_names2 = [item[0] for item in items]

    # Create a dropdown (combobox2)
    selected_item2 = tk.StringVar()
    dropdown2 = ttk.Combobox(Outlet3, textvariable=selected_item2, state="readonly", values=item_names2, font=("Arial", 12))
    dropdown2.place(x=170,y=420)
    dropdown2.set("Select an option")  # Default text


    # Extract names for the dropdown
    item_names3 = [item[0] for item in items]

    #Create a label
    label = tk.Label(Outlet3, text="Select an Item:", font=("Arial", 14))
    label.place(x=170,y=500)

    # Create a dropdown (combobox3)
    selected_item3 = tk.StringVar()
    dropdown3 = ttk.Combobox(Outlet3, textvariable=selected_item3, state="readonly", values=item_names3, font=("Arial", 12))
    dropdown3.place(x=170,y=530)
    dropdown3.set("Select an option")  # Default text
    
    # Create a label to display wattage
    Ext_Capacity = tk.Label(Outlet3, text = "Capacity: 2000W\n Recommended Use: 1600W", font=("Arial", 14), bg="black", fg="white")
    Ext_Capacity.place(x=10,y=840)
    wattage_label = tk.Label(Outlet3, text="Wattage: N/A", font=("Arial", 14), bg="black", fg="white")
    wattage_label.place(x=10, y=900)

    def show_selection():
        # Get the selected item's name
        selected_name = selected_item.get()
        
        # Find the wattage for the selected item
        for item in items:
            if item[0] == selected_name:
                wattage = item[1]
                break
        else:
            wattage = "wipwop"  # Default if not found

        # Display the selection and wattage
        print(f"Selected Item: {selected_name}, Wattage: {wattage}")

        # Get the selected item's name
        selected_name2 = selected_item2.get()
        
        # Find the wattage for the selected item
        for item in items:
            if item[0] == selected_name2:
                wattage2 = item[1]
                break
        else:
            wattage = "wipwop"  # Default if not found

        # Display the selection and wattage
        print(f"Selected Item: {selected_name2}, Wattage: {wattage2}")

        # Get the selected item's name
        selected_name3 = selected_item3.get()
        
        # Find the wattage for the selected item
        for item in items:
            if item[0] == selected_name3:
                wattage3 = item[1]
                break
        else:
            wattage = "wipwop"  # Default if not found

        # Display the selection and wattage
        print(f"Selected Item: {selected_name3}, Wattage: {wattage3}")

        Wattage_Total = wattage + wattage2 + wattage3

        wattage_label.config(text=f"Wattage: {Wattage_Total} W")





    # Add a button to confirm the selection
    btn_select = tk.Button(Outlet3, text="Confirm", command=show_selection)
    btn_select.place(x=280,y=180)






#=============================================================== MAIN WINDOW INITIALIZATION =============================================================
# Initialize the main window
root = tk.Tk()
root.title("Electronics Evaluator")
root.geometry("702x960")
root.config(bg="light gray")
root.resizable(0,0)

#Back to the main window
bgimg = PhotoImage(file='MAIN-PAGE-bg.png')
BgLabel=Label(image = bgimg).pack()


#=============================================================== EXTENSION SIMULATOR. MALAPIT NA AKO MASIRAAN =============================================================
# Function for button actions
def extension_simulator():
    root.destroy()


    #Create new window
    Ext_Window = tk.Tk()
    Ext_Window.geometry("702x960")
    Ext_Window.title("Extension Simulator")
    Ext_Window.config(bg="black")
    Ext_Window.resizable(0,0)
    
    global bgimg
    bgimg = PhotoImage(file='MAIN-PAGE-bg.png')
    BgLabel = Label(Ext_Window, image=bgimg)
    BgLabel.pack()

    #Label
    title = tk.Label(Ext_Window, text="Select an extension", font=("ROG Fonts", 20), fg="#fc7019", justify='center')
    title.place(x=40,y=80)

    #Create a dropdown

    # Fetch items from MySQL database
    items = Dropdown_for_db()
    if not items:
        items = ["No items found"]  # Fallback if no data is fetched

    # Create a label
    label = tk.Label(Ext_Window, text="Select an Item:", font=("Arial", 14))
    label.place(x=50,y=150)

    # Create a dropdown (combobox)
    selected_item = tk.StringVar()
    dropdown = ttk.Combobox(Ext_Window, textvariable=selected_item, state="readonly", values=items, font=("Arial", 12))
    dropdown.place(x=50,y=180)
    dropdown.set("Select an option")  # Default text
    

    # Function to display the selected item
    def show_selection():
        print(f"Selected Item: {selected_item.get()}")
        WhatElectronic = selected_item.get().strip()
        print(f"Selected Item: {WhatElectronic}")
        if WhatElectronic == "Omni Indoor 3 Outlet":
                Ext_Window.destroy()
                Outlet3Extension()
                print("i'm working")

        

    # Add a button to confirm the selection
    btn_select = tk.Button(Ext_Window, text="Confirm", command=show_selection)
    btn_select.place(x=280,y=180)


#=============================================================== ELECTRONICS SEARCH. MALAYO PA SA KATOTOHANAN =============================================================
def electronics_search():
    root.destroy()

    #Create new window
    Elec_search = tk.Tk()
    Elec_search.geometry("702x960")
    Elec_search.title("Electronic Detail Search")

    #Initialize Bg Image
    global bgimg
    bgimg = PhotoImage(file='MAIN-PAGE-bg.png')
    BgLabel=Label(Elec_search,image = bgimg)
    BgLabel.pack()

    #Information Label
    InfoLabel = tk.Label(Elec_search, text="Reminder. AIRCONS AND FRIDGES ARE \nNOT RECOMMENDED TO BE USED WITH AN EXTENSION.", font=("ROG Fonts", 15), fg="#fc7019", justify='center')
    InfoLabel.place(x=20, y=500)


    # Function to handle suggestive search
    def update_suggestions(event):
        typed = search_var.get()  # Get the input from the search bar

        if typed == '':  # Clear suggestions if search bar is empty
            listbox_suggestions.delete(0, END)
        else:
            # Clear the previous suggestions
            listbox_suggestions.delete(0, END)

            # Fetch the data from the database using the user input as part of the query
            query = f"SELECT Name FROM El WHERE Name LIKE '%{typed}%'"
            results = collect_data(query)  # Fetch suggestions from MySQL database

            # Add suggestions that match the user input
            for result in results:
                listbox_suggestions.insert(END, result[0])  # Insert suggestion into the Listbox
    
    # Function to fetch details and open a new window
    def show_item_details():
        

        # Get the selected item from the Listbox
        selected_index = listbox_suggestions.curselection()
        if not selected_index:
            print("No item selected!")
            return
        
        selected_item = listbox_suggestions.get(selected_index)
        print(f"Selected Item: {selected_item}")

        # Fetch details from the database
        query = f"SELECT * FROM El WHERE Name = '{selected_item}'"
        result = collect_data(query)

        if not result:
            print("No details found for the selected item.")
            return

        # Extract details (customize as per your database structure)
        item_details = result[0] 

        # Create a new window to display details
        detail_window = tk.Toplevel()
        detail_window.geometry("702x960")
        detail_window.title("Item Details")
        detail_window.resizable(0,0)
        
        #Initialize Bg Image
        global bgimg
        bgimg = PhotoImage(file='MAIN-PAGE-bg.png')
        BgLabel=Label(detail_window,image = bgimg)
        BgLabel.pack()

        # Display the details
        detail_label = tk.Label(detail_window, text=f"Details for '{selected_item}':", font=("Arial", 16, "bold"))
        detail_label.pack(pady=10)

        #Display Info of selected item
        details_text = f"ModelNum: {item_details[0]}\nBrand: {item_details[1]}\nName: {item_details[2]}\nWattage: {item_details[3]}\nReview: {item_details[4]} Out of 5"
        
        item_image_path = item_details[0].strip()
        global item_image
        item_image = PhotoImage(file=f'Electronics/{item_image_path}.png')
        item_image_label=Label(detail_window,image = item_image)
        item_image_label.place(x=40,y=90)

        item_info_label = tk.Label(detail_window, text=details_text, font=("Times", 15), justify=LEFT)
        item_info_label.place(x=250, y=480)
        
        

    # Auto Suggestive Search Bar
    search_var = StringVar()

    # Create the Entry (Search Bar)
    search_entry = tk.Entry(Elec_search, textvariable=search_var, font=('Helvetica', 14))
    search_entry.place(x=40, y=90)

    # Bind the key release event to dynamically update suggestions
    search_entry.bind("<KeyRelease>", update_suggestions)

    # Create the Listbox to show suggestions
    listbox_suggestions = Listbox(Elec_search, width=50, height=10)
    listbox_suggestions.place(x=40, y=120)

    # Button to display item details
    btn_show_details = tk.Button(Elec_search, text="Show Details", font=("Arial", 12), command=show_item_details)
    btn_show_details.place(x=40, y=300)


#=============================================================== BACK TO THE MAIN WINDOW STUUUFS =============================================================
# Title
title = tk.Label(root, text="ELECTRONICS\nEVALUATOR", font=("ROG Fonts", 30), fg="#fc7019", justify='center')
title.place(x=181,y=100)

# Subtitle
subtitle = tk.Label(root, text="Select an option:", font=("Times", 35,"bold"), fg="#fc7019", justify='center')
subtitle.place(x=181,y=250)

# Extension Simulator button
extension_picture = PhotoImage(file = 'extension_photo.png')
extension_label = Label(image=extension_picture)
extension_button = Button(image=extension_picture, command = extension_simulator)
extension_button.place(x=40,y=500)

#Extension Simulator Label
ext_label = Label(text = "EXTENSION\nSIMULATOR", font=("Times", 35,"bold"), fg="#fc7019")
ext_label.place(x=40,y=350)

# Search Electronics Detail button
search_picture = PhotoImage(file = 'electronics_photo.png')
search_label = Label(image=search_picture)
search_button = Button(image=search_picture, command = electronics_search)
search_button.place(x=380,y=500)

#Search Electronics Label
ext_label = Label(text = "SEARCH\nELECTRONICS\nDETAILS", font=("Times", 28, "bold"), fg="#fc7019")
ext_label.place(x=381,y=350)

# Run the GUI loop
root.mainloop()

#class Ext_Sim()